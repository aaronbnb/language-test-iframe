!// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
function(e,n,r,t,o){/* eslint-disable no-undef */var i="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},u="function"==typeof i[t]&&i[t],f=u.cache||{},l="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function a(n,r){if(!f[n]){if(!e[n]){// if we cannot find the module within our internal map or
// cache jump to the current global require ie. the last bundle
// that was added to the page.
var o="function"==typeof i[t]&&i[t];if(!r&&o)return o(n,!0);// If there are other bundles on this page the require from the
// previous one is saved to 'previousRequire'. Repeat this as
// many times as there are bundles until the module is found or
// we exhaust the require chain.
if(u)return u(n,!0);// Try the node require function if it exists.
if(l&&"string"==typeof n)return l(n);var d=Error("Cannot find module '"+n+"'");throw d.code="MODULE_NOT_FOUND",d}s.resolve=function(r){var t=e[n][1][r];return null!=t?t:r},s.cache={};var c=f[n]=new a.Module(n);e[n][0].call(c.exports,s,c,c.exports,this)}return f[n].exports;function s(e){var n=s.resolve(e);return!1===n?{}:a(n)}}a.isParcelRequire=!0,a.Module=function(e){this.id=e,this.bundle=a,this.exports={}},a.modules=e,a.cache=f,a.parent=u,a.register=function(n,r){e[n]=[function(e,n){n.exports=r},{}]},Object.defineProperty(a,"root",{get:function(){return i[t]}}),i[t]=a;for(var d=0;d<n.length;d++)a(n[d]);if(r){// Expose entry point to Node, AMD or browser globals
// Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
var c=a(r);// CommonJS
"object"==typeof exports&&"undefined"!=typeof module?module.exports=c:"function"==typeof define&&define.amd?define(function(){return c}):o&&(this[o]=c)}}({"2R9Hq":[function(e,n,r){/**
 * Get information about the current browser where the extension is installed.
 * Note: This is required as Chrome does not support browser.runtime.getBrowserInfo()
 *
 * @export
 * @returns {Object} Includes browser name and version
 */var t=e("@parcel/transformer-js/src/esmodule-helpers.js");function o(){let e;let n=navigator.userAgent,r=n.match(/(opera|chrome|safari|firefox|msie|trident|edge(?=\/))\/?\s*(\d+)/i)||[];if(/trident/i.test(r[1]))return{name:"IE",version:(e=/\brv[ :]+(\d+)/g.exec(n)||[])[1]||""};if("Chrome"===r[1]){if(null!=(e=n.match(/\bOPR\/(\d+)/)))return{name:"Opera",version:e[1]};if(null!=(e=n.match(/\bEdge\/(\d+)/)))return{name:"Edge",version:e[1]};if(null!=(e=n.match(/\bEdg\/(\d+)/)))return{name:"Edge (Chromium)",version:e[1]}}return r=r[2]?[r[1],r[2]]:[navigator.appName,navigator.appVersion,"-?"],null!=(e=n.match(/version\/(\d+)/i))&&r.splice(1,1,e[1]),{name:r[0],version:r[1]}}function i(e){let n=document.createElement("a");return n.href=e,-1!=["https:","http:"].indexOf(n.protocol)}t.defineInteropFlag(r),t.export(r,"getBrowserInfo",()=>o),/**
 * Is the URL one of the supported protocols; http or https?
 *
 * @export
 * @param {String} urlString
 * @returns {Boolean}
 */t.export(r,"isSupportedProtocol",()=>i)},{"@parcel/transformer-js/src/esmodule-helpers.js":"lKnE2"}],lKnE2:[function(e,n,r){r.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},r.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},r.exportAll=function(e,n){return Object.keys(e).forEach(function(r){"default"===r||"__esModule"===r||n.hasOwnProperty(r)||Object.defineProperty(n,r,{enumerable:!0,get:function(){return e[r]}})}),n},r.export=function(e,n,r){Object.defineProperty(e,n,{enumerable:!0,get:r})}},{}]},["2R9Hq"],"2R9Hq","parcelRequire420a");